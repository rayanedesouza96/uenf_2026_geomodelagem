# teste > 2026-07-02 1:48pm
https://universe.roboflow.com/rayanes-workspace-emhhr/teste-esd8a

Provided by a Roboflow user
License: CC BY 4.0

